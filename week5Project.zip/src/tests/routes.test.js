import supertest from "supertest";

import app from "../app.js";

test("the rout /findRecipe should return an object in any case", async () => {
  const res = await supertest(app)
    .get("/findRecipes")
    .query("")
    .expect(200)
    .expect("Content-Type", /json/);
  expect(res.body).toBeInstanceOf(Object);
  expect(Object.keys(res.body).length).toBeGreaterThan(0);
});

test(`typing hello or any form of greeting in /findRecipe the ai should return a msg that contain a sentence the 
  suggests  finding recipes`, async () => {
  const res = await supertest(app)
    .get("/findRecipes")
    .query("hello")
    .expect(200)
    .expect("Content-Type", /json/);
  expect(res.body).toBeInstanceOf(Object);

  const message = res.body.msg;
  expect(
    message.includes("recipes") ||
      message.includes("cooking") ||
      message.includes("recipe") ||
      message.includes("help")
  ).toBe(true);
});

test("should return 404 for invalid route", async () => {
  const res = await supertest(app)
    .get("/invalidRoute") // Sending a request to an invalid route
    .expect(404); // Expecting a 404 Not Found status
  console.log(res.body);

  expect(res.body).toBeInstanceOf(Object);
  // expect(res.body).toHaveProperty("error", "Not Found"); // Assuming the error message is "Not Found"
});
